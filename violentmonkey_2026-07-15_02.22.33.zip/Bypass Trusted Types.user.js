// ==UserScript==
// @name         Bypass Trusted Types
// @match        https://mail.google.com/*
// @match        https://www.youtube.com/*
// @match        https://www.google.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

if (window.trustedTypes && window.trustedTypes.createPolicy) {
    if (!window.trustedTypes.defaultPolicy) {
        window.trustedTypes.createPolicy('default', {
            createHTML: (s) => s,
            createScript: (s) => s,
            createScriptURL: (s) => s
        });
    }
}