// ==UserScript==
// @name         Bypass Trusted Types tamp
// @namespace    http://tampermonkey.net/
// @match        https://mail.google.com/*
// @match        https://www.youtube.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

if (window.trustedTypes && window.trustedTypes.createPolicy) {
    if (!window.trustedTypes.defaultPolicy) {
        window.trustedTypes.createPolicy('default', {
            createHTML: (s) => s,
            createScript: (s) => s,
            createScriptURL: (s) => s
        });
    }
}