// ==UserScript==
// @name         eval functions tamp
// @namespace    http://tampermonkey.net/
// @version      2026-04-15
// @description  try to take over the world!
// @author       You
// @match        *://*/*
// @match        file:///*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant       GM.setClipboard
// @grant       GM_xmlhttpRequest
// @grant       GM_setValue
// @grant       GM_getValue
// @grant       GM.notification
// @grant       GM_openInTab
// @connect     *
// @require     file:///C:/My%20Downloads/GM_files_Chrome/common.js
// @require     file:///C:/My%20Downloads/GM_files_Chrome/Yandex_Google_Translate.js
// @require     file:///C:/My%20Downloads/GM_files_Chrome/EVAL_Good-Chrome.js
// @require     file:///C:/My%20Downloads/GM_files_Chrome/Raznoe.js
// @resource  MY_PAGE file:///C:/My%20Downloads/GM_files_Chrome/Clippings.txt
// @grant     GM_getResourceText
// ==/UserScript==

window.addEventListener('message', function ede(e) {
  if (String(e.data).startsWith('postMsg$$$')) {
     console.log(e.data.split('postMsg$$$')[1])
    eval(e.data.split('postMsg$$$')[1])
  }
})

document.addEventListener('dragstart', e=>{
   let ac = document.activeElement, s, v,
       sel = getSelection();
   if (!sel.isCollapsed) {
      s = sel.getRangeAt(0).getBoundingClientRect();
      if (e.x>s.left && e.x<s.right) {
        setTimeout(()=>{
          if (!document.body.matches(":active")) {
             s.right-e.x>15 ? Google_Translate(e) : Yandex_Slovar(e)
          }
        }, 600);
      }
   };
   if (sel.isCollapsed && ac.value) {
     sel = ac.value.substring(ac.selectionStart, ac.selectionEnd);
     setTimeout(()=>{
        if (!e.target.matches(":active"))
          ac.selectionEnd-document.caretPositionFromPoint(e.x, e.y).offset>2 ?
           Google_Translate(e) : Yandex_Slovar(e)
     }, 600)
   }
})

window.addEventListener('spUpdated', function(e) {
    let data = e.detail; // Это то, что мы передали в { detail: ... }
    let z = data.match(/{x: (\d+?), y: (\d+?), name: '(.+?)'/);
    run(z[1], z[2], z[3], e)
})
function run(x, y, name, e) {
  if (name=='Local List') {                    /* ------------- Local List -------- */
     LocalList()
  }

  if (name=='Remove Stiky') {                  /* ------------- Remove Stiky -------- */
     RemoveSticky()
  }

  if (name=='Coord') {                         /* ------------- Coord -------- */
     Coord()
  }

  if (name=="Vremya") {                         /* ------------ Vremya -------- */
     Vremya()
  }

  if (name=="Element Attributes") {             /* ------------ Атрибуты элемента ----- */
    Attributes(x, y-123)
  }

  if (name=="Yandex Slovar") {                  /*-------------- Yandex Slovar -------- */
    Yandex_Slovar()
  }

  if (name=="get Text Content") {               /* ------------- get Text Content -------- */
      document.addEventListener('mousemove', r=> {
         getTextContent(r.clientX, r.clientY)
      }, {once:true})
  }

  if (name=="Right-Down") {                     /* ------------- Context Search -------- */
     var a=document.activeElement, se=String((a.contentWindow||window).getSelection()),
       s = se || a.value?.substring(a.selectionStart, a.selectionEnd);
     doRequest('file:///C:/My%20Downloads/GM_files_Chrome/Context_Search.txt', 'Context Search')
  }

  if (name=="Del") {                            /* ------------- Remove ❌ Element -------- */
     document.elementFromPoint(x, y-123).remove()
  }

  if (name=="Zakladki") {                       /* ------------- Zakladki  and  Clippings ------ */
     if (x>=1100) {
        let ip = GM_getResourceText('MY_PAGE');
        let w = window.open('', '', 'width=495, height=513, top=30, left=846');
        w.document.body.innerHTML = ip
     } else {
        Zakladki()
     }
  }

  if (name=="Url Decoder") {                  /* ------------- Keyboard Events & Url Decoder ------ */
     if (x>=1100)
        UrlDecoder();
     else
        KeyboardEvents();
  }

  if (name=="C") {                  /* ------------- Remove ❌ mydiv_class + Google search selection------ */
     let el = document.elementFromPoint(x, y-123);
     if (el.closest('.mydiv_class')) {
        el.closest('.mydiv_class').remove();
        let rm = document.querySelector('[ramka]');
        if (rm) {
           rm.style.border=''; rm.removeAttribute('ramka');
           if (rm.style.length == 0)rm.removeAttribute('style')
        }
           return
     } else {
         if (getSelection()!="") open('https://www.google.com/search?udm=web&q=' +getSelection());
         else {
            if (document.getElementById('t__')) return;
            let t = document.createElement('textarea'); t.id='t__'; t.className = 'mydiv_class';
            t.style.cssText=`position:fixed; top:${y - window.screenTop - 140}px;
               left:${x - 100}px; z-index:99999`;
            document.body.append(t); t.focus(); t.ondblclick =()=>t.remove();
            t.oninput =()=>{
               open('https://www.google.com/search?udm=web&q=' +t.value);
               t.remove()
            }
         }
     }
  }

    if (name=="Create Image") {                 /* -------------- wheelImg ---------- */
      document.querySelector('#img_for_scale')?.remove();
      var fromPoint = [...document.elementsFromPoint(x, y-123)];
      var ree = fromPoint.find(it=>it.localName=='img');
      var closest = fromPoint.find(it=> it.matches('[style*="background-image: url("]'));
      var bckgr = closest ? getComputedStyle(closest).backgroundImage.match(/"(.+?)"/)[1] : "";
      if (!ree && !bckgr) return;
      let src = ree?.src || bckgr;
      if (window !== window.top) {
        window.parent.postMessage('postMsg$$$createImg("' +src+ '")' , '*');
        return;
      }
       createImg(src, bckgr)
  }

  function doRequest(url, name, x_, y_) {
     GM_xmlhttpRequest({
        method: "GET",
        url: url,
        onload: function(response) {
           let ip = response.responseText,
               re = new RegExp ('@@' + name + '([\\s\\S]*?)@@'),
               q = ip.match(re);
           eval(q[1]) ;  //console.log(q[1]);
  }  }) }

} // ---- END run

function createProzr(el, ramka) {
   let Prozr = document.body.appendChild(document.createElement('span'));
   Prozr.style.cssText = `position:fixed; z-index:99999; top:0; left:0;
    right:0; bottom:0; width:100%; height:100%`;
   Prozr.id = 'ytProzr';
   Prozr.onclick = (e) => {
      if (e.target != el) {
         el?.remove();
         if (ramka) {
           ramka.style.border = '';
           ramka.style.length==0 && ramka.removeAttribute('style')
         }
         setTimeout(() => Prozr.remove(), 600)
}  }  }

function createImg(src, bckgr) {
  if (document.querySelector('#img_for_scale')) return;
  var img = document.createElement('img'); img.src = src;
  img.setAttribute('style', 'z-index:2147483647; position:fixed');
  img.id='img_for_scale';  img.className='mydiv_class mydrg'; document.body.append(img);
  document.querySelector('#predvImg')?.remove();
  img.onload=function(){
     img.style.width=img.style.minWidth=img.style.maxWidth=img.naturalWidth+'px';
     img.style.height=img.style.minHeight=img.style.maxHeight=img.naturalHeight+'px';
     img.style.left=document.documentElement.clientWidth/2 - img.naturalWidth/2+ 'px';
     img.style.top=window.innerHeight/2 - img.naturalHeight/2 + 'px';
  }
  if (bckgr) img.style.border = '7px dashed fuchsia';
  img.onwheel = function(e) { Scale(e, img) };
  img.ondblclick=function(){this.remove()};  Drag();
}



