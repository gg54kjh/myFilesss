// ==UserScript==
// @name         dblclick All tamp
// @namespace    http://tampermonkey.net/
// @version      2026-04-15
// @description  try to take over the world!
// @author       You
// @match        *://*/*
// @match       file:///*/*
// @grant       GM_setClipboard
// @grant       GM_xmlhttpRequest
// @grant       GM.xmlHttpRequest
// @grant       GM_notification
// @grant       GM_openInTab
// @connect *
// @require     file:///C:/My%20Downloads/GM_files_Chrome/common.js
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @resource  MY_PAGE
// @grant     GM_getResourceText
// ==/UserScript==

let X, Y, X_, Y_;
if (location.origin=='https://www.google.com') {
   var lnks =  document.querySelectorAll('a');
   for(var d of lnks){
     if (d.hasAttribute('data-jsarwt'))
       d.removeAttribute('data-jsarwt');
    }
}
document.addEventListener('mousedown', r=> {
  X = r.clientX; Y = r.clientY;
  X_ = r.pageX; Y_ = r.pageY;
});

document.addEventListener('dragend', g=> {
  if (g.clientY-Y>=20) {
    if (X-g.clientX>=-15) {
      showHref(g); return
    }
    else if (X-g.clientX<15) {getTitle(g)}
  }
});

// ------ Show Href in span -------
function showHref(e) {
  let a = e.target;
  if(a.nodeType!=3 && a.closest('a')) {
     var t = e.pageY +'px', l = e.pageX +'px',
         d = document.createElement('div');
     d.style.cssText='position:absolute;border:1px solid;padding:4px;background:#fffcdd;z-index:99999;\
     white-space:nowrap;color:black;font-size:16px;top:' +t+ ';left:' +l;
     d.innerHTML=decodeURIComponent(a.closest('a').href); d.id='dadada'; d.className='mydiv_class';
     document.body.addEventListener('mousedown', function mj(e){
       if(e.target!=d) {
         d?.remove(); document.body.removeEventListener('mousedown', mj)
       }
     });
     document.body.append(d); createProzr(d);
     if (parseInt(getComputedStyle(d).right)<0) {
       d.style.removeProperty('left');
       d.style.right = "0"
     }
   }
}

// ------ Get Title -------
function getTitle(e) {
  var url = e.target.closest('a')?.href;
  var tooltip = document.createElement("span");
  tooltip.className = 'getTitle mydiv_class';
  tooltip.style.cssText = "font-size: 22px !important; font-family: arial; position:absolute; background: #FFFCDD;" +
   "color: #000; text-align: center;" + "padding:4px 7px !important; border: 1px solid; z-index:2147483647; " +
   "border-radius: 7px; top: " + (Y_-20) + "px; left: " + (X_+10) + "px; max-width: 550px";
  document.addEventListener('click', e=>{
     if (e.target!==tooltip) {
        tooltip.remove()
     }
  }, {once: true})
  document.body.appendChild(tooltip);  createProzr(tooltip);
  if (location.href.includes('.yaplakal.com/')) {
    fetch(url)
    .then( async (response) => {
       var ip = await response.text(),
           x = new DOMParser().parseFromString(ip, "text/html");
       tooltip.innerHTML = x.title
    })
     return
  } else {
  GM_xmlhttpRequest({
    method: "GET",
    url: url,
    onload: function(response) {
      let y = response.responseText.match(/<title[\S\s]*?>([\S\s]*?)<\/title>/),
          x = y ? y[1] : 'og:title<br>' +response.responseText.match(/"og:title" content="([\S\s]*?)"/)[1],
          z =document.createElement('textarea'); z.innerText = x;

      tooltip.textContent = z.value
    }
  })
  };
}

// ------ createProzr -------
function createProzr(el) {
   let Prozr = document.body.appendChild(document.createElement('span'));
   Prozr.style.cssText = `position:fixed; z-index:99999; top:0; left:0;
    right:0; bottom:0; width:100%; height:100%`;
   Prozr.id = 'ytProzr';
   Prozr.onclick = (e) => {
      if (e.target != el) {
         el?.remove();
         setTimeout(() => Prozr.remove(), 600)
}  }  }
