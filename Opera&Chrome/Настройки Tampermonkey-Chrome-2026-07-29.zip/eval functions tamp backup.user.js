// ==UserScript==
// @name         eval functions tamp backup
// @namespace    http://tampermonkey.net/
// @version      2026-04-15
// @description  try to take over the world!
// @author       You
// @match        *://*/*
// @match        file:///*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant       GM.setClipboard
// @grant       GM_xmlhttpRequest
// @grant       GM_setValue
// @grant       GM_getValue
// @grant       GM.notification
// @grant       GM_openInTab
// @connect     *
// @require     https://raw.githubusercontent.com/gg54kjh/myFiles/refs/heads/main/common.js
// @require     https://raw.githubusercontent.com/gg54kjh/myFilesss/refs/heads/main/Yandex_Google_Translate.js
// @resource  MY_PAGE
// @grant     GM_getResourceText
// ==/UserScript==

window.addEventListener('message', function ede(e) {
  if (String(e.data).startsWith('postMsg$$$')) {
     console.log(e.data.split('postMsg$$$')[1])
    eval(e.data.split('postMsg$$$')[1])
  }
})

document.addEventListener('dragstart', e=>{
   let ac = document.activeElement, s, v,
       sel = getSelection();
   if (!sel.isCollapsed) {
      s = sel.getRangeAt(0).getBoundingClientRect();
      if (e.x>s.left && e.x<s.right) {
        setTimeout(()=>{
          if (!document.body.matches(":active")) {
             s.right-e.x>15 ? Google_Translate(e) : Yandex_Slovar(e)
          }
        }, 600);
      }
   };
   if (sel.isCollapsed && ac.value) {
     sel = ac.value.substring(ac.selectionStart, ac.selectionEnd);
     setTimeout(()=>{
        if (!e.target.matches(":active"))
          ac.selectionEnd-document.caretPositionFromPoint(e.x, e.y).offset>2 ?
           Google_Translate(e) : Yandex_Slovar(e)
     }, 600)
   }
})

document.addEventListener('keydown', run);
function run(e) {
  if (e.altKey && e.keyCode==49) {                       /* ------------- alt + 1  Local List ------ */
    doRequest("file:///C:/My%20Downloads/GM_files_Chrome/EVAL_Good.txt", 'Local List')
  }

  if (e.altKey && e.keyCode==50) {                       /* ------------- alt + 2  Sticky -------- */
     doRequest("file:///C:/My%20Downloads/GM_files_Chrome/EVAL_Good.txt", 'Remove Sticky')
  }

  if (e.altKey && e.keyCode==51 && !e.shiftKey) {        /* ------------- alt + 3  Coord -------- */
     doRequest("file:///C:/My%20Downloads/GM_files_Chrome/EVAL_Good.txt", "Coord")
  }

  if (e.altKey && e.keyCode==52) {                       /* ------------- alt + 4  Vremya -------- */
     doRequest("file:///C:/My%20Downloads/GM_files_Chrome/EVAL_Good.txt", 'Vremya')
  }

  if (e.altKey && e.keyCode==53) {                       /* ------------- alt + 5 Атрибуты элемента ----- */
    doRequest("file:///C:/My%20Downloads/GM_files_Chrome/Raznoe.txt", "Attributes")
  }

  if (e.shiftKey && e.keyCode==54) {                     /* ------------- shift + 6 Yandex Slovar  -------- */
    doRequest("https://raw.githubusercontent.com/gg54kjh/myFilesss/refs/heads/main/Yandex_Google_Translate.txt", "Yandex Slovar")
  }

  if (e.altKey && e.keyCode==55) {                       /* ------------- alt + 7  get Text Content -------- */
    doRequest("file:///C:/My%20Downloads/GM_files_Chrome/Raznoe.txt", 'get Text Content')
  }

  if (e.altKey && e.keyCode==56) {                        /* ------------- alt + 8  Context Search -------- */
     var a=document.activeElement, se=String((a.contentWindow||window).getSelection()),
       s = se || a.value?.substring(a.selectionStart, a.selectionEnd);
     doRequest('file:///C:/My%20Downloads/GM_files_Chrome/Context_Search.txt', 'Context Search')
  }

  if (e.altKey && e.keyCode==57) {                       /* ------------- alt + 9  ❌ Element -------- */
     document.addEventListener('mousemove', k=>k.target.remove(), {once: true})
  }

  if (e.altKey && e.keyCode==48) {                       /* ------------- alt + 0  Clippings -------- */
    fetch('https://raw.githubusercontent.com/gg54kjh/myFilesss/refs/heads/main/Clippings.txt')
    .then( async (response) => {
        let ip = await response.text();
        let w = window.open('', '', 'width=470, height=475, left=909');
        w.document.body.innerHTML = ip
    })
  }

  if (e.ctrlKey && e.shiftKey && e.keyCode==49) {        /* ------------- ctrl + shift + 1  Zakladki ------ */
    doRequest("file:///C:/My%20Downloads/GM_files_Chrome/Zakladki.txt", "Zakladki")
  }

  if (e.ctrlKey && e.shiftKey && e.keyCode==51) {        /* ------------- ctrl + shift + 3  Url Decoder ------ */
    doRequest("file:///C:/My%20Downloads/GM_files_Chrome/Raznoe.txt", 'Url Decoder')
  }

   if (e.ctrlKey && e.shiftKey && e.keyCode==53) {       /* ------------- ctrl + shift + 5  keyboard events ------ */
    doRequest("file:///C:/My%20Downloads/GM_files_Chrome/Raznoe.txt", 'Keyboard Events')
  }

  if (e.ctrlKey && e.shiftKey && e.keyCode==123) {       /* ------------- ctrl + shift + F12 ❌ mydiv_class ------ */
     document.addEventListener('mousemove', r=> {
        r.target.closest('.mydiv_class') && r.target.closest('.mydiv_class').remove();
        let rm = document.querySelector('[ramka]');
        if (rm) {
          rm.style.border=''; rm.removeAttribute('ramka');
          if (rm.style.length == 0)rm.removeAttribute('style')
        }
        if (getSelection()!="") open('https://www.google.com/search?udm=web&q=' +getSelection());
        else {
           let t = document.createElement('textarea'); t.className = 'mydiv_class';
           t.style.cssText='position:fixed; top:250px; left:600px; z-index:99999';
           document.body.append(t); t.focus(); t.ondblclick =()=>t.remove();
           t.oninput =()=>{
             open('https://www.google.com/search?udm=web&q=' +t.value);
             t.remove()
           }
        }
     }, {once: true})
  }

  if (e.ctrlKey && e.shiftKey && e.keyCode==50) {         /* ----------- ctrl + shift + 2  wheelImg ---------- */
    document.addEventListener('mousemove', function wheelImg(m){
      document.querySelector('#img_for_scale')?.remove();
      var ree = [...document.elementsFromPoint(m.clientX, m.clientY)].find(it=>it.localName=='img');
      var closest = m.target.closest('[style*="background-image: url("]');
      var bckgr = closest ? getComputedStyle(closest).backgroundImage.match(/"(.+?)"/)[1] : "";
      if (!ree && !bckgr) return;
      let src = ree?.src || bckgr;
      if (window !== window.top) {
        window.parent.postMessage('postMsg$$$createImg("' +src+ '")' , '*');
        return;
      }
       createImg(src, bckgr)
    }, {once: true})
  }

  if (e.keyCode==120) {
setTimeout(()=>{
let attr = document.head.getAttribute('spLastGesture')?.split(' ');
if (attr[2]=='C') {
  searchGoogle(attr[0], attr[1]);
  function searchGoogle(x, y) {
    if (getSelection()!="") open('https://www.google.com/search?udm=web&q=' +getSelection());
    else { if (document.querySelector('#t__')) return;
       let t = document.createElement('textarea'); t.id = 't__'; t.className = 'mydiv_class';
       t.style.cssText=`position:fixed; top:${y - window.screenTop - 140}px; left:${x - 100}px; z-index:99999`;
       document.body.append(t); t.focus(); t.ondblclick =()=>t.remove();
       t.oninput =()=>{
          open('https://www.google.com/search?udm=web&q=' +t.value);
          t.remove()
        }
     }
   }
}
}, 30)
  }

  function doRequest(url, name) {
     GM_xmlhttpRequest({
        method: "GET",
        url: url,
        onload: function(response) {
           let ip = response.responseText,
               re = new RegExp ('@@' + name + '([\\s\\S]*?)@@'),
               q = ip.match(re);
           eval(q[1]) ;  //console.log(q[1]);
  }  }) }

}

function createProzr(el, ramka) {
   let Prozr = document.body.appendChild(document.createElement('span'));
   Prozr.style.cssText = `position:fixed; z-index:99999; top:0; left:0;
    right:0; bottom:0; width:100%; height:100%`;
   Prozr.id = 'ytProzr';
   Prozr.onclick = (e) => {
      if (e.target != el) {
         el?.remove();
         if (ramka) {
           ramka.style.border = '';
           ramka.style.length==0 && ramka.removeAttribute('style')
         }
         setTimeout(() => Prozr.remove(), 600)
}  }  }

function createImg(src, bckgr) {
  if (document.querySelector('#img_for_scale')) return;
  var img = document.createElement('img'); img.src = src;
  img.setAttribute('style', 'z-index:2147483647; position:fixed');
  img.id='img_for_scale';  img.className='mydiv_class mydrg'; document.body.append(img);
  document.querySelector('#predvImg')?.remove();
  img.onload=function(){
     img.style.width=img.style.minWidth=img.style.maxWidth=img.naturalWidth+'px';
     img.style.height=img.style.minHeight=img.style.maxHeight=img.naturalHeight+'px';
     img.style.left=document.documentElement.clientWidth/2 - img.naturalWidth/2+ 'px';
     img.style.top=window.innerHeight/2 - img.naturalHeight/2 + 'px';
  }
  if (bckgr) img.style.border = '7px dashed fuchsia';
  img.onwheel = function(e) { Scale(e, img) } ;
  img.ondblclick=function(){this.remove()} ;  Drag();
}

