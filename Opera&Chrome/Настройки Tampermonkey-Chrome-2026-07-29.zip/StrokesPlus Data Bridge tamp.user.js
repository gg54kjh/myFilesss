// ==UserScript==
// @name         StrokesPlus Data Bridge tamp
// @description  Lua<>Js
// @version      1
// @match        *://*/*
// @match        file:///*/*
// @grant        GM.xmlHttpRequest
// @run-at       document-start
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mozilla-russia.org
// ==/UserScript==

window.spLastGesture = {x: 0, y: 0, name: 0};
window.addEventListener('keydown', function(e) {
   if (e.key === "F9") {
      e.preventDefault();
      let oldScript = document.getElementById('lua-bridge');
      if (oldScript) oldScript.remove();

      let script = document.createElement('script');
      script.id = 'lua-bridge';
      script.src = 'file:///C:/temp/coords.js?t=' + Date.now();

      GM.xmlHttpRequest({
         method: "GET",
         url: 'file:///C:/temp/coords.js?t=' + Date.now(),
         onload: function(response) {
            let u = response.responseText;
            window.spLastGesture = u;
            let currentData = window.spLastGesture;
            if (currentData) {
                window.dispatchEvent(new CustomEvent('spUpdated', { detail: currentData }));
            }
         }
     })
   }
});


